# Smart Rewards Gujarat (starter demo)

A beginner-friendly Android starter project with a Gujarati demo login screen and rewards dashboard. The login button is a demo navigation button, not real authentication. Points and wallet values are sample UI only; no real money movement, account storage, or redemption is implemented.

## Build APK on GitHub
1. Create a GitHub repository named `smart-rewards-gujarat`.
2. Upload the contents of this folder to the repository root (including `.github/workflows/build-apk.yml`).
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Choose **Build Android APK**, press **Run workflow**, then run it on `main`.
5. Open the completed workflow run and download the `Smart-Rewards-Gujarat-debug-apk` artifact. Extract the downloaded ZIP to get `app-debug.apk`.

This debug APK is for testing. Before a public release, implement real authentication, server-side point accounting, privacy/security controls, and a proper wallet/rewards backend.
