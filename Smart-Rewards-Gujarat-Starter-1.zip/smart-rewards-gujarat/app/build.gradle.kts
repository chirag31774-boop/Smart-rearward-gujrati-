plugins { id("com.android.application") }

android {
    namespace = "com.smartrewards.gujarat"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.smartrewards.gujarat"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
