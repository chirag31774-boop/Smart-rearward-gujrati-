package com.smartrewards.gujarat;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showLogin();
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); t.setGravity(Gravity.CENTER); return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(22),dp(22),dp(22),dp(22));
        l.setBackgroundColor(Color.rgb(247,245,255)); return l;
    }
    private void showLogin() {
        LinearLayout root = column(); root.setGravity(Gravity.CENTER);
        TextView logo = text("SRG", 32, Color.WHITE, true); logo.setBackground(bg(Color.rgb(79,35,150), 24));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(100),dp(100)); lp.gravity=Gravity.CENTER; lp.bottomMargin=dp(18); root.addView(logo,lp);
        root.addView(text("Smart Rewards Gujarat",25,Color.rgb(45,24,87),true));
        TextView sub=text("તમારા પોઇન્ટ્સ, તમારા રિવોર્ડ્સ",15,Color.DKGRAY,false); sub.setPadding(0,dp(8),0,dp(24)); root.addView(sub);
        Button login = button("લૉગિન / આગળ વધો"); root.addView(login, match());
        TextView note=text("આ પ્રારંભિક ડેમો છે. હજી સાચું એકાઉન્ટ કે વૉલેટ જોડાયેલું નથી.",13,Color.DKGRAY,false); note.setPadding(0,dp(20),0,0); root.addView(note);
        login.setOnClickListener(v -> showHome()); setContentView(root);
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTextSize(16);
        b.setBackground(bg(Color.rgb(79,35,150),14)); return b;
    }
    private LinearLayout.LayoutParams match() { return new LinearLayout.LayoutParams(-1, dp(54)); }
    private void showHome() {
        ScrollView scroll=new ScrollView(this); LinearLayout root=column(); scroll.addView(root);
        TextView title=text("નમસ્તે! 👋\nSmart Rewards Gujarat",25,Color.rgb(45,24,87),true); title.setGravity(Gravity.START); title.setPadding(0,dp(10),0,dp(22)); root.addView(title);
        LinearLayout points=new LinearLayout(this); points.setOrientation(LinearLayout.VERTICAL); points.setPadding(dp(18),dp(20),dp(18),dp(20)); points.setBackground(bg(Color.rgb(79,35,150),20));
        points.addView(text("તમારા કુલ પોઇન્ટ્સ",16,Color.WHITE,false)); points.addView(text("250 pts",34,Color.WHITE,true));
        root.addView(points,new LinearLayout.LayoutParams(-1,dp(130)));
        TextView wallet=text("👛  Wallet\n₹0.00  ·  ડેમો બેલેન્સ",18,Color.rgb(45,24,87),true); wallet.setBackground(bg(Color.WHITE,16)); wallet.setPadding(dp(16),dp(20),dp(16),dp(20));
        LinearLayout.LayoutParams wlp=match(); wlp.topMargin=dp(16); root.addView(wallet,wlp);
        TextView rh=text("તમારા રિવોર્ડ્સ",21,Color.rgb(45,24,87),true); rh.setGravity(Gravity.START); rh.setPadding(0,dp(24),0,dp(10)); root.addView(rh);
        root.addView(reward("🎁  મોબાઇલ રિચાર્જ", "500 પોઇન્ટ્સ જરૂરી"),match());
        LinearLayout.LayoutParams rlp=match(); rlp.topMargin=dp(10); root.addView(reward("🛍️  શોપિંગ વાઉચર", "1000 પોઇન્ટ્સ જરૂરી"),rlp);
        TextView foot=text("આ સ્ક્રીન માત્ર ડેમો છે. રિડીમ/પૈસા ઉપાડવાની સુવિધા સક્રિય નથી.",13,Color.DKGRAY,false); foot.setPadding(0,dp(20),0,0); root.addView(foot);
        Button back=button("લૉગઆઉટ"); LinearLayout.LayoutParams blp=match(); blp.topMargin=dp(18); root.addView(back,blp); back.setOnClickListener(v->showLogin()); setContentView(scroll);
    }
    private TextView reward(String title, String sub) {
        TextView t=text(title+"\n"+sub,17,Color.rgb(45,24,87),true); t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(dp(16),dp(10),dp(10),dp(10)); t.setBackground(bg(Color.WHITE,16));
        t.setOnClickListener(v->Toast.makeText(this,"રિવોર્ડ્સ હજી ડેમો મોડમાં છે",Toast.LENGTH_SHORT).show()); return t;
    }
}
